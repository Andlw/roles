#!/bin/bash

echo $@ >> sentinel_reconfig.log
