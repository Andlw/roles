codis's redis build & external librarys
